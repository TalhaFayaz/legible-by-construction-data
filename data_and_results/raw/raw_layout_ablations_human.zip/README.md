# Runs behind the paper's tables

Every number in the paper is recomputed from these files with the commands in
the code repository's `docs/reproduce.md`; none of those commands needs a GPU.
Unpack next to the repository so that `runs/` sits at its root.

Three models (Qwen2.5-VL-32B-Instruct, Gemma 4 26B-A4B-it, Ministral 3 14B
Instruct), three corpora (SciFlow-Bench 483 papers, FlowVQA 300 test items,
PaperBananaBench 292 diagram test cases), three seeds each.

| folder | what | paper |
|---|---|---|
| `runs/nocov_<corpus>_<model>_seed<S>/` | the evaluated pipeline (no coverage pass, control-flow mode on) | main results |
| `runs/final_<corpus>_<model>_seed<S>/`, `runs/final_flowvqa_<model>_cf_seed<S>/` | the same with the coverage pass | coverage comparison, ablation |
| `runs/dot_<corpus>_<model>/` | the same model writing DOT itself; `repaired.jsonl` is the scored file | DOT baseline |
| `runs/judge/` | PaperBananaBench judge verdicts, both image orders (`swap_` = swapped) | PaperBananaBench table |
| `runs/judge2/` | the same for seed 0 and the DOT figures with a second judge, Qwen2.5-VL-32B-Instruct; `RULE.md` is its decision rule as fixed before the run | second judge (Appendix B) |
| `runs/inverse/` | every figure read back by one reader, and the gold graphs | symmetric SciFlow table |
| `runs/pipeline_ablation_final/` | best-of-2 and constrained decoding switched off, seed 0 | pipeline ablation |
| `runs/pipeline_ablation/` | the earlier ablation, run with the coverage pass | not in the paper |
| `runs/layout_ablation_nocov/`, `runs/graphviz_nocov/` | layout engine components off; Graphviz `dot` on the same graphs | layout tables |
| `runs/placement_final/<model>_seed<S>/` | the model placing the boxes itself, all three models | placement ablation |
| `runs/placement_seed<S>/` | the earlier Qwen placement runs the human-study graphs come from | human study |
| `runs/dev2/` | development study that chose the pipeline variant (dev items only) | development choices |
| `runs/dotmatched/<corpus>_<model>/` | the same model writing DOT from our own prompts; `analysis.txt` applies the rule in `development/review_experiments/prompt_matched_dot/RULE.md`; judge files are `runs/judge/{,swap_}dotmatched_<model>.jsonl` | prompt-matched baseline (Table 2) |
| `runs/inverse/ceiling_gold.jsonl` | the gold graphs drawn by our engine and read back by the same reader | ceiling (read-back comparison) |
| `runs/graphviz_outdev/` | Graphviz `dot` against our engine on FlowVQA and PaperBananaBench graphs, seed 0 | layout on graphs outside development |
| `runs/analyses/` | parsed-subset, threshold and error analysis, judge score by figure size, route-cost sensitivity (`a8_cost/`) | robustness checks |
| `human_study/` | the 72 rated images' metadata and each rater's best-worst choices (raters R1, R2, ...) | human study |

In each run folder, `full.jsonl` holds one record per item (scores, layout
measures, timing) and `artifacts/<item>/` the extracted graph (`figure.json`)
and its layout (`layout.json`). Rendered images are not included: they are
re-rendered from the saved graphs, deterministically, by
`python3 -m ab.pdf.eval.InverseParse render --run <folder>`.

The corpora themselves are not redistributed; get them from their authors as
described in `docs/reproduce.md`. Server paths and addresses in logs are
replaced by `<home>`, `<server>` and `<user>`.

`development/` holds the development studies: each decision rule
as it was written before its runs, the scripts that ran the variants and applied
the rule, and their printed decisions. `with_without_coverage_f1.py` prints
the test-set comparison with and without the coverage call.

`development/review_experiments/` holds the scripts of the experiments added
after the internal review: the prompt-matched DOT baseline with its decision
rule (written and fingerprinted before the runs; `runs/dotmatched/rule.sha1`),
the ceiling check (`build_gold_figures.py` draws every gold graph with our
engine, then the reader reads it back), and the further analyses.
