"""Variant c of dev study 2: the extraction prompt asks for a concise figure.

Built from the repo's EXTRACTOR_PROMPT by three exact replacements, so the rest
of the prompt (gates, edge labels, loops, schema rules) is unchanged.
"""
from ab.pdf.agent.Extractor import EXTRACTOR_PROMPT

_DROP = """ A component
mentioned only once, or only at the very end, still becomes a node. Do not stop
listing when the narrative seems finished; passages usually name several systems
after the main sequence is over.
"""
_KEEP_STEP = """
STEP 1b -- KEEP THE FIGURE READABLE. The graph is drawn as one figure that a
reader takes in at a glance, like the overview figure of a paper. From your
list keep the main stages and components: about 8 to 15 boxes in total,
counting children. A step that is part of a larger stage is merged into that
stage or goes in its "children"; a detail that only one sentence mentions is
left out. Prefer one node per stage of the method over one node per sentence.
"""
_RULE_OLD = "- Capture EVERY component the passage names, and every flow between them."
_RULE_NEW = ("- Capture every main stage and component, and every flow between them;\n"
             "  leave minor details out (STEP 1b).")

assert _DROP in EXTRACTOR_PROMPT and _RULE_OLD in EXTRACTOR_PROMPT
CONCISE_PROMPT = (EXTRACTOR_PROMPT
                  .replace(_DROP, "\n" + _KEEP_STEP)
                  .replace(_RULE_OLD, _RULE_NEW))
assert "STEP 1b" in CONCISE_PROMPT and "{text}" in CONCISE_PROMPT
