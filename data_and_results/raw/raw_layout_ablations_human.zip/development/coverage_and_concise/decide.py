"""Apply DECISION_RULE.md to the finished dev study 2 runs. Prints every number it uses.

    python3 decide.py            (reads runs/dev2/<model>/<set>_<variant>/)
"""
import json
import statistics as st
from pathlib import Path

from scipy.stats import wilcoxon

O = Path("runs/dev2")
MODELS = ["qwen", "gemma4", "ministral"]
P = {"Model": 100, "Human": 0}


def score_file(path):
    """item -> official score, and the failed items, for an FV/SF run."""
    recs = [json.loads(l) for l in open(path)]
    return ({r["paper_id"]: r["native"]["final_score"] for r in recs},
            {r["paper_id"] for r in recs if r["failed"]},
            {r["paper_id"]: r["domain"] for r in recs})


def judge_file(run):
    """item -> overall points, mean of both image orders, for a PB run."""
    a = {json.loads(l)["id"]: json.loads(l) for l in open(run / "judge.jsonl")}
    b = {json.loads(l)["id"]: json.loads(l) for l in open(run / "judge_swap.jsonl")}
    assert set(a) == set(b) and len(a) == 60, run
    failed = {json.loads(l)["paper_id"] for l in open(run / "full.jsonl") if json.loads(l)["failed"]}
    return {i: (P.get(a[i]["overall"], 50) + P.get(b[i]["overall"], 50)) / 2 for i in a}, failed


def test(x, y, ids):
    d = [x[i] - y[i] for i in ids]
    p = wilcoxon(d).pvalue if any(d) else 1.0
    return st.mean(x[i] for i in ids), st.mean(y[i] for i in ids), st.mean(d), p


rows, helps, guards_fail = [], {"b": [], "c": []}, {"b": [], "c": []}
pb_gain = {"b": [], "c": []}
for m in MODELS:
    for s in ("pb", "fv", "sf"):
        if s == "pb":
            base, fbase = judge_file(O / m / "pb_a")
        else:
            base, fbase, dom = score_file(O / m / f"{s}_a" / "full.jsonl")
        for v in ("b", "c"):
            if s == "pb":
                var, fvar = judge_file(O / m / f"pb_{v}")
            else:
                var, fvar, _ = score_file(O / m / f"{s}_{v}" / "full.jsonl")
            ids = sorted(set(base) & set(var))
            mv, mb, md, p = test(var, base, ids)
            limit = 2.0 if s == "pb" else 0.01
            worse = (md < 0 and p < 0.05) or (-md >= limit) or (len(fvar) > len(fbase) + 1)
            better = md > 0 and p < 0.05
            rows.append(f"{m:9s} {s:2s} {v}: a {mb:7.3f}  {v} {mv:7.3f}  diff {md:+7.3f}  p {p:.3g}  "
                        f"failed a/{v} {len(fbase)}/{len(fvar)}  {'WORSE' if worse else ('better' if better else 'same')}")
            if worse:
                guards_fail[v].append(f"{m} {s}")
            if s == "pb":
                pb_gain[v].append(md)
                if better and m in ("gemma4", "ministral"):
                    helps[v].append(f"{m} pb")
            if s == "fv" and m == "gemma4":
                inst = [i for i in ids if dom[i] == "instruct"]
                imv, imb, imd, ip = test(var, base, inst)
                rows.append(f"{'':9s} fv instruct only {v}: a {imb:.3f}  {v} {imv:.3f}  diff {imd:+.3f}  p {ip:.3g}")
                if imd > 0 and ip < 0.05:
                    helps[v].append("gemma4 fv-instruct")

print("Dev study 2 (dev sets only; not a result)\n")
print("\n".join(rows))
print()
qualifying = []
for v in ("b", "c"):
    gain = st.mean(pb_gain[v])
    print(f"variant {v}: helps on {helps[v] or 'nothing'}; guards failed: {guards_fail[v] or 'none'}; "
          f"mean PB-ref gain over models {gain:+.1f}")
    if helps[v] and not guards_fail[v]:
        qualifying.append((v, gain))
print()
if not qualifying:
    trade = [v for v in ("b", "c") if helps[v] and guards_fail[v]]
    print("DECISION: no variant qualifies." + (f" Trade-off to report to the user: {trade} help but fail a guard."
                                                if trade else " Nothing changes."))
elif len(qualifying) == 1:
    print(f"DECISION: adopt variant {qualifying[0][0]}")
else:
    (v1, g1), (v2, g2) = sorted(qualifying, key=lambda x: -x[1])
    print(f"DECISION: adopt variant {'b' if abs(g1 - g2) < 2 else v1} (gains {v1} {g1:+.1f}, {v2} {g2:+.1f})")
