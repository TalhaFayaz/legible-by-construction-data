"""Dev study 2 runner: one variant, one dev set, one model (see DECISION_RULE.md).

Uses the repo's RunCorpus.run unchanged, with its item list replaced by the dev
set, so selection, scoring and the saved artefacts are exactly the pipeline's.

    PYTHONPATH=. python3 run_dev.py VARIANT SET OUT_DIR      (VARIANT a|b|c, SET pb|fv|sf)
"""
import json
import random
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
R = Path("runs")
PB_REF = HERE / "pb_ref" / "diagram_ref60.parquet"


def pb_parquet() -> Path:
    """The 60 ref diagrams, written once (with their human figures) for RunCorpus and the judge."""
    if not PB_REF.exists():
        import pyarrow.parquet as pq
        from huggingface_hub import hf_hub_download
        table = pq.read_table(hf_hub_download("dwzhu/PaperBananaBench", "data/diagram/ref-00000-of-00001.parquet",
                                              repo_type="dataset"))
        ids = sorted(random.Random(11).sample(table.column("id").to_pylist(), 60))
        test = pq.read_table("data/paperbanana/diagram_test.parquet", columns=["id", "source_pdf"])
        keep = [r for r in table.to_pylist() if r["id"] in set(ids)]
        assert not {r["source_pdf"] for r in keep} & set(test.column("source_pdf").to_pylist())
        PB_REF.parent.mkdir(exist_ok=True)
        import pyarrow as pa
        pq.write_table(pa.Table.from_pylist(keep, schema=table.schema), PB_REF)
    return PB_REF


def items(which: str):
    if which == "pb":
        from ab.pdf.corpus import PaperBanana
        return list(PaperBanana.iter_items(pb_parquet()))
    if which == "fv":
        from ab.pdf.corpus import FlowVQA
        train = json.loads(Path("data/flowvqa/train_full.json").read_text())
        test_texts = {v.get("text") or v.get("code")
                      for v in json.loads(Path("data/flowvqa/test_full.json").read_text()).values()}
        out = []
        for source in ("wiki", "instruct"):
            keys = sorted(k for k, r in train.items() if k.startswith(source) and r.get("text") not in test_texts)
            for key in sorted(random.Random(13).sample(keys, 30)):
                rec = train[key]
                out.append(FlowVQA.BenchItem(paper_id=key, domain=source, prompt=FlowVQA.prompt_of(rec),
                                             gold_graph=FlowVQA.parse_mermaid(rec["mermaid"]),
                                             gold_layout=FlowVQA.Layout(), baselines={}))
        return out
    if which == "sf":
        from ab.pdf.corpus.AutoBench import load_item
        gold = json.loads((R / "inverse/gold.json").read_text())
        keys = sorted(gold)
        random.Random(7).shuffle(keys)
        return [load_item(Path("data/sciflow_raw") / k.split("/")[0] / k.split("/")[1], domain=k.split("/")[0])
                for k in sorted(keys[:40])]
    raise SystemExit(f"unknown set {which}")


if __name__ == "__main__":
    variant, which, out_dir = sys.argv[1], sys.argv[2], Path(sys.argv[3])
    import ab.pdf.agent.Extractor as X
    from ab.pdf.eval import RunCorpus

    if variant == "c":
        from concise import CONCISE_PROMPT
        X.EXTRACTOR_PROMPT = CONCISE_PROMPT
    dev = items(which)
    RunCorpus._items = lambda dataset, root, limit: dev
    RunCorpus.run(Path("."), out_dir / "full.jsonl", n=2, coverage=(variant == "a"),
                  dataset={"pb": "paperbanana", "fv": "flowvqa", "sf": "sciflow"}[which])
