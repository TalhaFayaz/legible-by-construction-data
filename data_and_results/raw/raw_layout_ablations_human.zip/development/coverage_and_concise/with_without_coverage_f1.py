"""Variant b (no coverage pass) vs the current pipeline on the official F1 metrics.

Per item the mean over seeds 0-2 of each run; paired two-sided Wilcoxon, Holm over the
3 models per dataset and metric. FlowVQA current = the control-flow runs (final_flowvqa_{m}_cf).
    python3 analyse_f1.py [flowvqa|sciflow ...]
"""
import json
import statistics as st
import sys
from pathlib import Path

from scipy.stats import wilcoxon

R = Path("runs")
MODELS = ["qwen", "gemma4", "ministral"]
METRICS = ["node_f1", "edge_f1", "final_score"]
CURRENT = {"flowvqa": "final_flowvqa_{m}_cf_seed{s}", "sciflow": "final_sciflow_{m}_seed{s}"}


def per_item(pattern, m, metric):
    runs = []
    for s in (0, 1, 2):
        recs = [json.loads(l) for l in open(R / pattern.format(m=m, s=s) / "full.jsonl")]
        runs.append({(r["domain"], r["paper_id"]): (r["native"] or {}).get(metric, 0.0) for r in recs})
    assert all(set(x) == set(runs[0]) for x in runs), pattern
    return {k: st.mean(x[k] for x in runs) for k in runs[0]}


for ds in sys.argv[1:] or ["flowvqa", "sciflow"]:
    print(f"\n{ds}: no coverage pass vs current pipeline (3 seeds averaged per item; Wilcoxon, Holm over 3 models)")
    for metric in METRICS:
        res = []
        for m in MODELS:
            new = per_item(f"nocov_{ds}_{{m}}_seed{{s}}", m, metric)
            old = per_item(CURRENT[ds], m, metric)
            assert set(new) == set(old), (ds, m)
            d = [new[k] - old[k] for k in sorted(new)]
            res.append((m, st.mean(new.values()), st.mean(old.values()), st.mean(d),
                        wilcoxon(d).pvalue if any(d) else 1.0, len(d)))
        holm, run = {}, 0
        for j, r in enumerate(sorted(res, key=lambda x: x[4])):
            run = max(run, min(1, (len(res) - j) * r[4])); holm[r[0]] = run
        for m, n, o, d, p, k in res:
            v = "same" if holm[m] >= 0.05 else ("better" if d > 0 else "worse")
            print(f"  {metric:11s} {m:10s} n {k}  nocov {n:.3f}  current {o:.3f}  diff {d:+.4f}  "
                  f"p {p:.2g}  Holm {holm[m]:.2g}  -> {v}")
