# Dev study 2 (9 Nov 2026): concise figures — decision rule, fixed before any run

Nothing here is a reported result. No test item of any dataset is used.

## Variants (all with n = 2 candidates and the pipeline's geometric selection)
- **a** current pipeline (prompt revision 3, coverage pass, control-flow mode)
- **b** a without the coverage pass
- **c** concise prompt (`concise.py`: keep the main stages and components, about
  8–15 boxes counting children, merge minor steps, leave one-sentence details
  out), without the coverage pass. Program text is unaffected (control-flow mode).

## Dev sets (fixed before running)
- **PB-ref**: 60 PaperBananaBench *ref* diagrams, `random.Random(11).sample` of the
  298 ref ids. 0 ids and 0 source PDFs shared with the 292 test cases.
- **FV-train**: 60 FlowVQA *train* items, 30 wiki + 30 instruct, `random.Random(13)`,
  excluding any text that also occurs in the test split. (Code items left out:
  the variants do not change how a program is drawn.)
- **SF-dev**: the same 40 SciFlow-Bench papers used for prompt revision 3
  (seed 7 sample of gold.json keys).

Models: Qwen2.5-VL-32B, Gemma 4 26B, Ministral 3 14B; `VLLM_SEED=0`, `VLLM_CACHE=0`,
`VLLM_MAX_TOKENS` 5000 on PB-ref, 12000 otherwise.

## Metrics
- PB-ref: the benchmark judge (InternVL3.5-14B, official prompts), per item the
  mean of both image orders of the overall verdict (100 / 0 / 50).
- FV-train, SF-dev: the official score (0.4 node F1 + 0.6 edge F1) per item.
- Tests: paired two-sided Wilcoxon against variant **a**, per model and set.

## Rule
1. **Target.** A variant *helps* if, against **a**, its mean is higher with
   p < 0.05 on PB-ref for Gemma or Ministral, or on the FV-train instruct items
   for Gemma.
2. **Guards.** For every model and every set (PB-ref, FV-train, SF-dev) it must
   not be worse than **a**: no lower mean with p < 0.05, a mean drop on
   FV-train/SF-dev below 0.01, a mean drop on PB-ref below 2 points, and at most
   one more failed item than **a**.
3. A variant that helps and passes every guard **qualifies**. Of those, take the
   larger mean gain on PB-ref averaged over the three models; if the two gains
   differ by less than 2 points, take **b** (one component fewer, no new prompt).
4. If a variant helps but fails a guard, nothing is adopted automatically: the
   trade-off is reported to the user, who decides.
5. If none qualifies, nothing changes and the current results stand.
6. An adopted variant applies to all datasets and models; every test run it
   changes is re-run once, in full, and both versions are reported.
