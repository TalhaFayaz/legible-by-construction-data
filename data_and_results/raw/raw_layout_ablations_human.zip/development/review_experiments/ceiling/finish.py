"""Finish the ceiling run: InverseParse render stopped at the first error (a 391-Mpixel gold
figure tripped PIL's decompression-bomb guard). Render the rest one by one with the guard lifted
(the reader scales every image to 1600 px anyway) and errors caught per figure, then read only the
newly rendered figures (read_system resumes)."""
import logging
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

from PIL import Image

sys.path.insert(0, "<home>")
Image.MAX_IMAGE_PIXELS = None
R = Path("runs")


def render(path):
    logging.disable(logging.CRITICAL)
    Image.MAX_IMAGE_PIXELS = None
    from ab.pdf.eval.InverseParse import _render_one
    try:
        return _render_one(Path(path))
    except Exception as e:
        print(f"render failed {Path(path).parent.name}: {str(e)[:120]}", flush=True)
        return False


if __name__ == "__main__":
    todo = [str(f) for f in sorted((R / "ceiling_gold/artifacts").glob("*/figure.json"))
            if not f.with_name("figure.png").exists()]
    with ProcessPoolExecutor(3) as pool:
        ok = sum(pool.map(render, todo))
    print(f"rendered {ok} of {len(todo)} remaining", flush=True)
    from ab.pdf.eval.InverseParse import read_system
    read_system(R / "inverse/gold.json", str(R / "ceiling_gold/artifacts/{domain}__{paper}/figure.png"),
                R / "inverse/ceiling_gold.jsonl", workers=4)
    print("read done", flush=True)
