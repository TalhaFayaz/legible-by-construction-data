#!/bin/bash
# Reader ceiling (review Major 4): gold graphs drawn by our engine, read back by the same reader.
cd <home>
R=runs
export VLLM_BASE=http://<server>:30041 VLLM_MODEL=internvl3.5-14b VLLM_CACHE=0 VLLM_SEED=0 VLLM_MAX_TOKENS=4000 PYTHONPATH=.
python3 -m ab.pdf.eval.InverseParse render --run $R/ceiling_gold --workers 4 > $R/ceiling_gold/render.log 2>&1
echo "$(date +%H:%M) rendered $(ls $R/ceiling_gold/artifacts/*/figure.png | wc -l)"
python3 -m ab.pdf.eval.InverseParse read --gold $R/inverse/gold.json \
  --images "$R/ceiling_gold/artifacts/{domain}__{paper}/figure.png" \
  --out $R/inverse/ceiling_gold.jsonl --workers 4 > $R/ceiling_gold/read.log 2>&1
echo "$(date +%H:%M) read $(wc -l < $R/inverse/ceiling_gold.jsonl)"
