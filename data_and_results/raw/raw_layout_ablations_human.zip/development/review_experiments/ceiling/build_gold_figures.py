"""Ceiling of the symmetric SciFlow-Bench reading (review Major 4).

Each paper's gold graph becomes a figure (one box per gold node with its text,
one arrow per gold edge, no labels or containers), drawn by our engine exactly
as our runs are drawn (InverseParse render), and read back by the same reader
with the same prompt (InverseParse read). Its score against the same gold graph
is what a perfect extraction would score after read-back: the reader's ceiling.

Writes runs/ceiling_gold/artifacts/<domain>__<paper>/figure.json
(domain in the folder: 40 papers have two different gold graphs).
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, "<home>")
from ab.pdf.dto.Ir import Edge, FlowFigure, Node  # noqa: E402

R = Path("runs")
gold = json.loads((R / "inverse/gold.json").read_text())
out = R / "ceiling_gold/artifacts"
n = 0
for key, g in sorted(gold.items()):
    domain, paper = key.split("/")
    ids = {}
    nodes = []
    for i, node in enumerate(g["nodes"]):
        nid = re.sub(r"[^a-z0-9_]", "_", str(node["node_id"]).lower()) or f"n{i}"
        if nid in ids.values():
            nid = f"{nid}_{i}"
        ids[node["node_id"]] = nid
        nodes.append(Node(id=nid, label=(node.get("desc") or "").strip() or nid))
    edges = [Edge(source=ids[e["from"]], target=ids[e["to"]])
             for e in g["edges"]
             if e["from"] in ids and e["to"] in ids and e["from"] != e["to"]]
    folder = out / f"{domain}__{paper}"
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "figure.json").write_text(FlowFigure(nodes=nodes, edges=edges).model_dump_json())
    n += 1
print(f"{n} gold figures written to {out}")
