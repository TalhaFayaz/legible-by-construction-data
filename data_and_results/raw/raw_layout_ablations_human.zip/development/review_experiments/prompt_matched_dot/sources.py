"""FlowVQA per source: ours vs matched DOT (Holm over the three models per source)."""
import statistics as st, sys
sys.path.insert(0, "<home>")
sys.argv = ["x"]
sys.path.insert(0, "session_keep/dotmatched")
from ab.pdf.eval.ModelComparison import compare, holm
import importlib.util
spec = importlib.util.spec_from_file_location("an", "session_keep/dotmatched/analyse.py")
import io, contextlib
an = importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):
    spec.loader.exec_module(an)
for src in ("wiki", "instruct", "code"):
    rows = []
    for m in an.MODELS:
        o = {k: v for k, v in an.ours("flowvqa", m).items() if k[0] == src}
        md = {k: v for k, v in an.dot("flowvqa", m, True)[0].items() if k[0] == src}
        ks = [k for k in o if k in md]
        r = compare({k: o[k] for k in ks}, {k: md[k] for k in ks})
        rows.append((m, len(ks), st.fmean(o[k] for k in ks), st.fmean(md[k] for k in ks), r))
    adj = holm([r["p"] if r else 1 for *_, r in rows])
    for (m, n, a, b, r), p in zip(rows, adj):
        v = "tied" if (r is None or p >= .05) else ("ahead" if r["r"] > 0 else "behind")
        print(f"{src:<9}{m:<10}{n:>4} ours {a:.3f} matched {b:.3f} r {r['r']:+.2f} p {p:.2g} {v}")
