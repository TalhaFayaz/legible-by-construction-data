#!/bin/bash
# Prompt-matched DOT baseline (rule: session_keep/dotmatched/RULE.md, sha1 in runs/dotmatched/rule.sha1).
# 3 models x 3 corpora, one process each, greedy, seed 0, same token limits as the plain DOT runs.
R=runs/dotmatched
cd <home>
: > $R/pids.txt
for spec in "qwen 31102 Qwen/Qwen2.5-VL-32B-Instruct" "gemma4 30039 gemma-4-26b-a4b-it" "ministral 30040 ministral-3-14b"; do
  set -- $spec; m=$1; port=$2; name=$3
  for ds in sciflow flowvqa paperbanana; do
    out=$R/${ds}_${m}; mkdir -p $out
    mt=12000; [ $ds = paperbanana ] && mt=5000
    DOT=$HOME/.local/opt/graphviz/bin/dot VLLM_BASE=http://<server>:$port VLLM_MODEL=$name \
      VLLM_CACHE=0 VLLM_SEED=0 VLLM_MAX_TOKENS=$mt PYTHONPATH=. \
      nohup python3 -m ab.pdf.eval.DotBaseline --dataset $ds --prompt matched \
      --out $out/full.jsonl > $out/log.txt 2>&1 &
    echo "$! ${ds}_${m}" >> $R/pids.txt
  done
done
cat $R/pids.txt
