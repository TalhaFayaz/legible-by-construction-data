"""Apply RULE.md (prompt-matched DOT baseline). Usage: analyse.py [MATCHED_PREFIX]
MATCHED_PREFIX defaults to runs/dotmatched/{ds}_{m}; for a dry run of the code it can point at
the plain DOT runs instead ("dry"), so no matched test output is read before the runs end."""
import statistics as st
import sys
from pathlib import Path

sys.path.insert(0, "<home>")
from ab.pdf.eval.ModelComparison import compare, holm, load  # noqa: E402
from ab.pdf.eval.PaperBananaJudge import scores  # noqa: E402
from ab.pdf.eval.PaperTables import key  # noqa: E402

R = Path("runs")
DRY = len(sys.argv) > 1 and sys.argv[1] == "dry"
MODELS = ("qwen", "gemma4", "ministral")


def sc(r):
    return (r.get("native") or {}).get("final_score", 0.0)


def ours(ds, m):
    if ds == "paperbanana":
        return judged([R / f"judge/{p}nocov_{m}_seed{s}.jsonl" for s in (0, 1, 2) for p in ("", "swap_")])
    per = {}
    for s in (0, 1, 2):
        for r in load(R / f"nocov_{ds}_{m}_seed{s}/full.jsonl"):
            per.setdefault(key(r), []).append(sc(r))
    return {k: st.fmean(v) for k, v in per.items()}


def judged(files):
    per = {}
    for f in files:
        for cid, d in scores(f).items():
            per.setdefault(("", cid), []).append(d["overall"])
    return {k: st.fmean(v) for k, v in per.items()}


def dot(ds, m, matched):
    """(scores, parsed keys)"""
    if ds == "paperbanana":
        name = "dot" if (not matched or DRY) else "dotmatched"
        s = judged([R / f"judge/{p}{name}_{m}.jsonl" for p in ("", "swap_")])
        run = R / (f"dot_paperbanana_{m}" if (not matched or DRY) else f"dotmatched/paperbanana_{m}")
        ok = {("", r["paper_id"]) for r in load(run / "full.jsonl") if not r.get("failed") and r.get("drawn")}
        return s, ok
    run = R / (f"dot_{ds}_{m}" if (not matched or DRY) else f"dotmatched/{ds}_{m}")
    f = run / ("repaired.jsonl" if ds == "sciflow" else "full.jsonl")
    rows = load(f)
    return {key(r): sc(r) for r in rows}, {key(r) for r in rows if not r.get("failed")}


def block(title, rows):
    out = [title, f"  {'model':<10}{'n':>5}{'A':>8}{'B':>8}{'diff':>9}  {'95% CI':<18}{'r':>6}{'p Holm':>9}  verdict"]
    adj = holm([r["p"] if r else 1.0 for _, r, *_ in rows])
    verdicts = []
    for (m, r, a, b), p in zip(rows, adj):
        v = "tied" if (r is None or p >= 0.05) else ("ahead" if r["r"] > 0 else "behind")
        verdicts.append(v)
        if r is None:
            out.append(f"  {m:<10} too few decided pairs: tied"); continue
        lo, hi = r["ci"]
        out.append(f"  {m:<10}{r['n']:>5}{a:>8.3f}{b:>8.3f}{r['diff']:>+9.3f}  [{lo:+.3f}, {hi:+.3f}]  {r['r']:>+6.2f}{p:>9.2g}  {v}")
    return "\n".join(out), verdicts


def pair(a, b, keep=None):
    ks = [k for k in a if k in b and (keep is None or k in keep)]
    aa, bb = {k: a[k] for k in ks}, {k: b[k] for k in ks}
    return compare(aa, bb), st.fmean(aa.values()), st.fmean(bb.values())


out = ["DRY RUN: plain DOT stands in for matched DOT; not a result" if DRY else
       "Prompt-matched DOT baseline - RULE.md applied (A = first system, B = second)"]
c1_ahead = 0
for ds in ("sciflow", "flowvqa", "paperbanana"):
    c1, c2, c3 = [], [], []
    fails = {}
    for m in MODELS:
        o = ours(ds, m)
        md, mok = dot(ds, m, True)
        pd, _ = dot(ds, m, False)
        fails[m] = len(md) - len(mok)
        c1.append((m, *pair(o, md)))
        c2.append((m, *pair(md, pd)))
        c3.append((m, *pair(o, md, mok)))
    metric = "overall judge score" if ds == "paperbanana" else "score"
    t, v = block(f"\n{ds} ({metric}); matched DOT without a usable answer: {fails}\nC1 ours vs matched DOT", c1)
    c1_ahead += v.count("ahead")
    out.append(t)
    out.append(block("C2 matched DOT vs plain DOT", c2)[0])
    out.append(block("C3 ours vs matched DOT, items where matched DOT parsed", c3)[0])
out.append(f"\nC1: ours ahead of matched DOT in {c1_ahead} of 9 settings.")
out.append("DECISION: " + ("keep the claim that the representation, not only the prompt, carries the gains"
                           if c1_ahead >= 5 else
                           "state that the structural gains come from the prompt; credit the representation "
                           "with reliability and layout only"))
print("\n".join(out))
