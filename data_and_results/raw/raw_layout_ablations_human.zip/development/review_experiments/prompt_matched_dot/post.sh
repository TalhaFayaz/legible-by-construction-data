#!/bin/bash
# After the matched-DOT runs: judge PaperBananaBench (both orders), repair SciFlow-Bench answers
# (same two repairs as the plain baseline), then apply RULE.md. Waits on PIDs only.
R=runs
M=$R/dotmatched
cd <home>
pid() { awk -v n="$1" '$2==n {print $1}' $M/pids.txt; }
wait_pid() { while kill -0 "$1" 2>/dev/null; do sleep 60; done; }
for m in gemma4 qwen ministral; do
  wait_pid $(pid paperbanana_$m)
  run=$M/paperbanana_$m
  for order in "" "--swapped"; do
    out=$R/judge/$([ -n "$order" ] && echo swap_)dotmatched_$m.jsonl
    VLLM_BASE=http://<server>:30041 VLLM_MODEL=internvl3.5-14b VLLM_CACHE=0 VLLM_SEED=0 PYTHONPATH=. \
      python3 -m ab.pdf.eval.PaperBananaJudge judge --workers 8 $order \
      --images "$run/artifacts/{id}/figure.png" --out $out >> $M/judge.log 2>&1
  done
  echo "$(date +%H:%M) judged paperbanana_$m $(wc -l < $R/judge/dotmatched_$m.jsonl) $(wc -l < $R/judge/swap_dotmatched_$m.jsonl)"
done
for m in gemma4 qwen ministral; do
  wait_pid $(pid sciflow_$m)
  DOT=$HOME/.local/opt/graphviz/bin/dot PYTHONPATH=. python3 -m ab.pdf.eval.DotBaseline --dataset sciflow \
    --out $M/sciflow_$m/full.jsonl --repair $M/sciflow_$m/repaired.jsonl
done
while read p name; do wait_pid $p; done < $M/pids.txt
cd <home>
python3 session_keep/dotmatched/analyse.py > $M/analysis.txt 2> $M/analysis.err
echo "$(date +%H:%M) ANALYSIS DONE"
tail -3 $M/analysis.txt
