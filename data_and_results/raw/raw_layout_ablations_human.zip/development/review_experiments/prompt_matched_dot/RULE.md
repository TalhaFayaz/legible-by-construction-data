# Prompt-matched DOT baseline (15 Nov 2026) - rule fixed before the runs

Question (review Major 1): is our pipeline ahead of the same model writing DOT because of the
prompt, or because of the coordinate-free graph under constrained decoding?

Baseline "matched DOT": `DotBaseline --prompt matched`. The model gets the pipeline's own extraction
prompt (or the control-flow prompt when `is_code` fires), word for word, plus one fixed block
(DOT_FORMAT) mapping our graph's fields to DOT. One greedy answer, seed 0, same servers, same
VLLM_MAX_TOKENS as the plain DOT runs (12000; 5000 on PaperBananaBench). Graphviz reads it exactly as
the plain baseline. On SciFlow-Bench the same two mechanical repairs (`--repair`) are applied, as for
the plain baseline. DOT_FORMAT is written once and frozen with this rule; it is not revised after
looking at any test output. A smoke test on 2 FlowVQA *training* items checks only the plumbing
(the run completes and writes records); a fix there may touch code, not the prompt text.

Runs: 3 models x {SciFlow-Bench 483, FlowVQA 300, PaperBananaBench 292}. PaperBananaBench figures are
judged by InternVL3.5-14B in both orders, as every other system.

Comparisons (same statistics as Table 2: per item, ours = mean of the 3 nocov seeds; paired Wilcoxon,
rank-biserial r, 95 % bootstrap CI, Holm over the 3 models per corpus and metric; verdict by sign of r
at alpha 0.05). Metric: score (SciFlow-Bench, FlowVQA), overall judge score (PaperBananaBench).
  C1 ours vs matched DOT                (primary)
  C2 matched DOT vs plain DOT           (how much the prompt alone buys)
  C3 ours vs matched DOT on items where matched DOT parsed (secondary; separates parse failures)

Decision, fixed now:
  - If ours is ahead of matched DOT (C1) in at least 5 of 9 settings, the paper keeps the claim that
    the coordinate-free representation, not only the prompt, carries the structural gains.
  - Otherwise the paper states that the structural gains come from the prompt, and credits the
    representation with reliability (no parse failures, guaranteed layout) and layout quality only.
  - In either case Table 2 reports both baselines (plain and matched DOT), and C2 and C3 are reported.
Nothing else (prompt, tokens, repair rule, metric, items) changes after the first test output.
