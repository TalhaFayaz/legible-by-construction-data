"""Review Major 6 (existing runs): does PaperBananaBench penalise figures for being large?
Per test case: judge score (overall and conciseness; both orders and, for ours, three seeds
averaged) against the number of boxes drawn and the length of the method section.
Also: ours vs DOT on the cases where ours draws at most as many boxes as DOT."""
import json
import statistics as st
import sys
from pathlib import Path

from scipy.stats import spearmanr

sys.path.insert(0, "<home>")
from ab.pdf.eval.ModelComparison import compare  # noqa: E402
from ab.pdf.eval.PaperBananaJudge import scores  # noqa: E402

R = Path("runs")


def judge(files):
    per = {}
    for f in files:
        for cid, d in scores(f).items():
            per.setdefault(cid, []).append(d)
    return {cid: {k: st.fmean(x[k] for x in v) for k in v[0]} for cid, v in per.items()}


def size(run_dirs):
    per = {}
    for d in run_dirs:
        for line in (d / "full.jsonl").read_text().splitlines():
            r = json.loads(line)
            if not r.get("failed") and r.get("pred_nodes"):
                per.setdefault(r["paper_id"], []).append(r["pred_nodes"])
    return {k: st.fmean(v) for k, v in per.items()}


out = []
for m in ("qwen", "gemma4", "ministral"):
    o = judge([R / f"judge/{p}nocov_{m}_seed{s}.jsonl" for s in (0, 1, 2) for p in ("", "swap_")])
    d = judge([R / f"judge/{p}dot_{m}.jsonl" for p in ("", "swap_")])
    on = size([R / f"nocov_paperbanana_{m}_seed{s}" for s in (0, 1, 2)])
    dn = size([R / f"dot_paperbanana_{m}"])
    out.append(f"== {m}: boxes per figure, ours {st.fmean(on.values()):.1f} (median {st.median(on.values()):.0f}), "
               f"DOT {st.fmean(dn.values()):.1f} (median {st.median(dn.values()):.0f})")
    for who, sc, n in (("ours", o, on), ("DOT", d, dn)):
        ks = [k for k in sc if k in n]
        for dim in ("overall", "conciseness"):
            rho, p = spearmanr([n[k] for k in ks], [sc[k][dim] for k in ks])
            out.append(f"  {who:<5} rho(boxes, {dim:<11}) = {rho:+.2f} (p {p:.2g}, n {len(ks)})")
    ks = [k for k in o if k in d and k in on and k in dn]
    diff = {k: on[k] - dn[k] for k in ks}
    rho, p = spearmanr([diff[k] for k in ks], [o[k]["overall"] - d[k]["overall"] for k in ks])
    out.append(f"  rho(ours-DOT boxes, ours-DOT overall) = {rho:+.2f} (p {p:.2g})")
    small = [k for k in ks if on[k] <= dn[k]]
    r = compare({k: o[k]["overall"] for k in small}, {k: d[k]["overall"] for k in small})
    if r:
        out.append(f"  cases where ours draws <= DOT's boxes: n {r['n']}, ours {st.fmean(o[k]['overall'] for k in small):.1f}"
                   f" vs DOT {st.fmean(d[k]['overall'] for k in small):.1f}, diff {r['diff']:+.1f} "
                   f"[{r['ci'][0]:+.1f}, {r['ci'][1]:+.1f}], r {r['r']:+.2f}, p {r['p']:.2g}")
print("\n".join(out))
