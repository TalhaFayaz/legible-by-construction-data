"""Review Major 7: sensitivity of the layout results to the hand-set route-search costs.
Each of the five costs (Prepare.ROUTE_COSTS) is halved and doubled, one at a time; every saved
SciFlow-Bench graph of seed 0 (3 models) is laid out again; per configuration we report arrow
crossings, arrows through a box, label collisions and the strict check, with a paired Wilcoxon
test against the hand-set costs (Holm over the 10 changed configurations, per model and measure).
Output: runs/analyses/a8_cost/<model>_<config>.json, then a summary on stdout."""
import json
import logging
import multiprocessing
import sys
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

sys.path.insert(0, "<home>")
R = Path("runs")
OUT = R / "analyses/a8_cost"
MODELS = ("qwen", "gemma4", "ministral")
BASE = {"bend": 1.5, "cross": 5.0, "along": 25.0, "reuse": 12.0, "offset": 0.6}
CONFIGS = {"hand-set": {}}
for k in BASE:
    for f in (0.5, 2.0):
        CONFIGS[f"{k} x{f:g}"] = {k: BASE[k] * f}
MEASURES = (("edge_edge_crossings", "crossings"), ("edge_node_crossings", "through box"),
            ("label_collisions", "label coll."))


def one(job):
    path, config = job
    import ab.pdf.agent.Prepare as P
    from ab.pdf.dto.Ir import FlowFigure
    from ab.pdf.eval.GraphvizBaseline import _score
    from ab.pdf.eval.VlmAdapter import figure_to_planner_json, prepared_to_layout
    P.PARALLEL_FROM = 10 ** 9
    P.ROUTE_COSTS = {**BASE, **CONFIGS[config]}
    fig = FlowFigure.model_validate_json(Path(path).read_text())
    try:
        s = _score(prepared_to_layout(P.prepare(figure_to_planner_json(fig), 1.0)))
        return {"paper": Path(path).parent.name, "strict": bool(s["valid"]),
                **{k: s[k] for k, _ in MEASURES}}
    except Exception as e:
        return {"paper": Path(path).parent.name, "error": str(e)[:200]}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    with ProcessPoolExecutor(int(sys.argv[1]) if len(sys.argv) > 1 else 6,
                             mp_context=multiprocessing.get_context("fork"),
                             initializer=lambda: logging.disable(logging.CRITICAL)) as pool:
        for m in MODELS:
            figs = [str(f) for f in sorted((R / f"nocov_sciflow_{m}_seed0/artifacts").glob("*/figure.json"))]
            for config in CONFIGS:
                f = OUT / f"{m}_{config.replace(' ', '_')}.json"
                if not f.exists():
                    f.write_text(json.dumps(list(pool.map(one, [(p, config) for p in figs], chunksize=4))))
                    print(f"done {m} {config}", flush=True)
    summary()


def summary():
    import statistics as st
    from ab.pdf.eval.ModelComparison import compare, holm
    lines = ["Route-cost sensitivity, SciFlow-Bench seed 0 (mean per figure; strict %; "
             "Holm over the 10 changed configurations; * = significantly different from hand-set)"]
    for m in MODELS:
        rows = {c: {r["paper"]: r for r in json.loads((OUT / f"{m}_{c.replace(' ', '_')}.json").read_text())
                    if "error" not in r} for c in CONFIGS}
        base = rows["hand-set"]
        lines.append(f"\n{m}: {'config':<14}" + "".join(f"{lab:>14}" for _, lab in MEASURES) + f"{'strict %':>11}")
        tests = {}
        for k, _ in MEASURES + (("strict", ""),):
            res = []
            for c in list(CONFIGS)[1:]:
                shared = set(rows[c]) & set(base)
                res.append(compare({p: float(rows[c][p][k]) for p in shared}, {p: float(base[p][k]) for p in shared}))
            adj = holm([r["p"] if r else 1.0 for r in res])
            tests[k] = dict(zip(list(CONFIGS)[1:], adj))
        for c in CONFIGS:
            rr = rows[c]
            cells = ""
            for k, _ in MEASURES:
                star = "*" if c != "hand-set" and tests[k][c] < 0.05 else " "
                cells += f"{st.fmean(r[k] for r in rr.values()):>13.2f}{star}"
            star = "*" if c != "hand-set" and tests["strict"][c] < 0.05 else " "
            cells += f"{100 * st.fmean(r['strict'] for r in rr.values()):>10.1f}{star}"
            lines.append(f"   {c:<14}{cells}")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
