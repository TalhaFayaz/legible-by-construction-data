#!/bin/bash
# CPU queue (review Major 7): waits for the error analysis (PID $1), then
# (1) route-cost sensitivity, (2) dot vs our engine on graphs the engine was not developed on.
R=runs
while kill -0 $1 2>/dev/null; do sleep 60; done
cd <home>
OMP_NUM_THREADS=1 python3 session_keep/analyses/a8_cost_sensitivity.py 6 > $R/analyses/a8_cost_sensitivity.txt 2> $R/analyses/a8.err
echo "$(date +%H:%M) a8 done"
cd <home>
for ds in flowvqa paperbanana; do for m in qwen gemma4 ministral; do
  DOT=$HOME/.local/opt/graphviz/bin/dot OMP_NUM_THREADS=1 PYTHONPATH=. python3 -m ab.pdf.eval.GraphvizBaseline \
    --runs $R/nocov_${ds}_${m}_seed0 --out $R/graphviz_outdev/${ds}_${m} --workers 4 \
    > $R/graphviz_outdev/${ds}_${m}.txt 2> $R/graphviz_outdev/${ds}_${m}.err
  echo "$(date +%H:%M) graphviz $ds $m done"
done; done
echo "ALL DONE"
