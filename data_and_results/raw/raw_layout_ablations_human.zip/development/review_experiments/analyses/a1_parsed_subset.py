"""Review Major 1 (existing runs): ours vs the same model's plain DOT
(a) on all items, (b) only on items whose DOT answer parsed, and (c) FlowVQA per source.
Score metric; ours = mean of the three nocov seeds per item; Holm over the three models."""
import statistics as st
import sys
from pathlib import Path

sys.path.insert(0, "<home>")
from ab.pdf.eval.ModelComparison import compare, holm, load  # noqa: E402
from ab.pdf.eval.PaperTables import key  # noqa: E402

R = Path("runs")
MODELS = ("qwen", "gemma4", "ministral")


def score(r):
    return (r.get("native") or {}).get("final_score", 0.0)


def ours(ds, m):
    per = {}
    for s in (0, 1, 2):
        for r in load(R / f"nocov_{ds}_{m}_seed{s}/full.jsonl"):
            per.setdefault(key(r), []).append(score(r))
    return {k: st.fmean(v) for k, v in per.items()}


def dot(ds, m):
    f = R / f"dot_{ds}_{m}" / ("repaired.jsonl" if ds == "sciflow" else "full.jsonl")
    return {key(r): r for r in load(f)}


def block(title, rows):
    out = [title, f"  {'model':<10}{'n':>5}{'ours':>8}{'DOT':>8}{'diff':>9}  {'95% CI':<18}{'r':>6}{'p Holm':>9}  verdict"]
    adj = holm([r["p"] if r else 1.0 for _, r, *_ in rows])
    for (m, r, a, b), p in zip(rows, adj):
        if r is None:
            out.append(f"  {m:<10} too few decided pairs"); continue
        v = "tied" if p >= 0.05 else ("ahead" if r["r"] > 0 else "behind")
        lo, hi = r["ci"]
        out.append(f"  {m:<10}{r['n']:>5}{a:>8.3f}{b:>8.3f}{r['diff']:>+9.3f}  [{lo:+.3f}, {hi:+.3f}]  {r['r']:>+6.2f}{p:>9.2g}  {v}")
    return "\n".join(out)


lines = []
for ds in ("sciflow", "flowvqa"):
    for subset in ("all items", "DOT parsed"):
        rows = []
        for m in MODELS:
            o, d = ours(ds, m), dot(ds, m)
            keep = [k for k in o if k in d and (subset == "all items" or not d[k].get("failed"))]
            oo = {k: o[k] for k in keep}
            dd = {k: score(d[k]) for k in keep}
            rows.append((m, compare(oo, dd), st.fmean(oo.values()), st.fmean(dd.values())))
        nfail = {m: sum(r.get("failed", False) for r in dot(ds, m).values()) for m in MODELS}
        lines.append(block(f"{ds}, {subset} (DOT failures: {nfail})", rows))
for src in ("wiki", "instruct", "code"):
    rows = []
    for m in MODELS:
        o, d = ours("flowvqa", m), dot("flowvqa", m)
        keep = [k for k in o if k in d and k[0] == src]
        oo = {k: o[k] for k in keep}
        dd = {k: score(d[k]) for k in keep}
        rows.append((m, compare(oo, dd), st.fmean(oo.values()), st.fmean(dd.values())))
    lines.append(block(f"flowvqa, source {src}", rows))
print("\n\n".join(lines))
