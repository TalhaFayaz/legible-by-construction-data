"""Review Majors 4 and 8 (existing runs, seed 0 of ours; DOT as scored in the paper).

A. Threshold sensitivity: SciFlow-Bench score of ours and of the same model's DOT at node-matching
   thresholds 0.5 (the benchmark's), 0.6 and 0.7; paired Wilcoxon, Holm over the 3 models.
B. Error analysis against the gold graph at 0.5: node recall / precision, and every gold edge as
   found (same direction), reversed (only the opposite direction drawn), missed with both ends
   matched, or missed because an end is missing; gold back edges (loops) vs forward edges.
Failed items count with no prediction. Cross-listed SciFlow papers share one artifact folder,
so their figure is the one saved last (both areas' gold graphs are scored against it)."""
import json
import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, "<home>")
from ab.pdf.dto.Ir import FlowFigure  # noqa: E402
from ab.pdf.eval.DotBaseline import dot_graph, repair_dot  # noqa: E402
from ab.pdf.eval.ModelComparison import compare, holm  # noqa: E402
from ab.pdf.eval.RunCorpus import _gold_native, _items  # noqa: E402
from ab.pdf.metric.SciFlowNative import (figure_to_native, hybrid_similarity_matrix,  # noqa: E402
                                         semantic_edge_f1, semantic_node_f1)

R = Path("runs")
V = Path("<home>")
DOT = str(Path.home() / ".local/opt/graphviz/bin/dot")
MODELS = ("qwen", "gemma4", "ministral")
ROOTS = {"sciflow": V / "data/sciflow_raw", "flowvqa": V / "data/flowvqa/test_full.json"}


def ours_pred(ds, m, rec):
    if rec.get("failed"):
        return [], []
    f = R / f"nocov_{ds}_{m}_seed0/artifacts/{rec['paper_id']}/figure.json"
    return figure_to_native(FlowFigure.model_validate_json(f.read_text())) if f.exists() else ([], [])


def dot_pred(ds, m, rec):
    if rec.get("failed"):
        return [], []
    art = R / f"dot_{ds}_{m}/artifacts/{rec['paper_id']}"
    src = repair_dot((art / "answer.txt").read_text()) if rec.get("repaired") else (art / "figure.dot").read_text()
    try:
        return dot_graph(src, DOT)
    except Exception:
        return [], []


def back_edges(nodes, edges):
    """Gold edges closing a cycle (DFS from nodes in order)."""
    adj = {}
    for e in edges:
        adj.setdefault(e["from"], []).append(e["to"])
    state, back = {}, set()

    def dfs(u):
        state[u] = 1
        for v in adj.get(u, []):
            if state.get(v) == 1:
                back.add((u, v))
            elif v not in state:
                dfs(v)
        state[u] = 2
    sys.setrecursionlimit(10000)
    for n in nodes:
        if n["node_id"] not in state:
            dfs(n["node_id"])
    return back


def errors(gt_n, gt_e, pr_n, pr_e, t=0.5):
    c = Counter()
    if not gt_n:
        return c
    if pr_n:
        sim = hybrid_similarity_matrix(gt_n, pr_n)
        c["gold nodes"] += len(gt_n); c["gold nodes found"] += int((sim.max(axis=0) >= t).sum())
        c["pred nodes"] += len(pr_n); c["pred nodes matched"] += int((sim.max(axis=1) >= t).sum())
        m = {p["node_id"]: {gt_n[j]["node_id"] for j in range(len(gt_n)) if sim[i, j] >= t}
             for i, p in enumerate(pr_n)}
    else:
        c["gold nodes"] += len(gt_n); m = {}
    covered = set().union(*m.values()) if m else set()
    pairs = {(a, b) for e in pr_e for a in m.get(e["from"], ()) for b in m.get(e["to"], ())}
    back = back_edges(gt_n, gt_e)
    for e in gt_e:
        u, v = e["from"], e["to"]
        kind = "back" if (u, v) in back else "forward"
        if (u, v) in pairs:
            res = "found"
        elif (v, u) in pairs:
            res = "reversed"
        elif u in covered and v in covered:
            res = "missed, ends matched"
        else:
            res = "missed, end missing"
        c[f"{kind}:{res}"] += 1
    return c


out = []
for ds in ("sciflow", "flowvqa"):
    items = {(i.domain, i.paper_id): i for i in _items(ds, ROOTS[ds], None)}
    gold = {k: _gold_native(i) for k, i in items.items() if i.gold_graph.n_nodes}
    preds = {}
    for m in MODELS:
        o = {(r["domain"], r["paper_id"]): r for r in map(json.loads, open(R / f"nocov_{ds}_{m}_seed0/full.jsonl"))}
        dfile = R / f"dot_{ds}_{m}" / ("repaired.jsonl" if ds == "sciflow" else "full.jsonl")
        d = {(r["domain"], r["paper_id"]): r for r in map(json.loads, open(dfile))}
        preds[("ours", m)] = {k: ours_pred(ds, m, o[k]) for k in gold if k in o}
        preds[("DOT", m)] = {k: dot_pred(ds, m, d[k]) for k in gold if k in d}
    out.append(f"===== {ds}: threshold sensitivity (score; ours seed 0 vs DOT; Holm over 3 models)")
    for t in (0.5, 0.6, 0.7):
        rows = []
        for m in MODELS:
            sc = {}
            for who in ("ours", "DOT"):
                sc[who] = {}
                for k, (pn, pe) in preds[(who, m)].items():
                    gn, ge = gold[k]
                    nf = semantic_node_f1(gn, pn, t)[2]
                    ef = semantic_edge_f1(gn, ge, pn, pe, t)[2]
                    sc[who][k] = 0.4 * nf + 0.6 * ef
            rows.append((m, compare(sc["ours"], sc["DOT"]), sc))
        adj = holm([r["p"] if r else 1 for _, r, _ in rows])
        for (m, r, sc), p in zip(rows, adj):
            v = "tied" if p >= 0.05 else ("ahead" if r["r"] > 0 else "behind")
            mo = sum(sc["ours"].values()) / len(sc["ours"]); md = sum(sc["DOT"].values()) / len(sc["DOT"])
            out.append(f"  t={t}  {m:<10} ours {mo:.3f}  DOT {md:.3f}  diff {r['diff']:+.3f}  r {r['r']:+.2f}  p Holm {p:.2g}  {v}")
    out.append(f"===== {ds}: error analysis at 0.5 (shares of gold edges; node recall/precision)")
    for (who, m), pr in preds.items():
        c = Counter()
        for k, (pn, pe) in pr.items():
            c += errors(*gold[k], pn, pe)
        line = (f"  {who:<4} {m:<10} node recall {c['gold nodes found'] / max(1, c['gold nodes']):.2f}, "
                f"precision {c['pred nodes matched'] / max(1, c['pred nodes']):.2f} |")
        for kind in ("forward", "back"):
            tot = sum(v for k, v in c.items() if k.startswith(kind + ":"))
            if tot:
                line += f" {kind} ({tot}): " + ", ".join(
                    f"{res} {c[f'{kind}:{res}'] / tot:.2f}"
                    for res in ("found", "reversed", "missed, ends matched", "missed, end missing")) + " |"
        out.append(line)
    print("\n".join(out[-(len(out)):]), flush=True)
    out = []
