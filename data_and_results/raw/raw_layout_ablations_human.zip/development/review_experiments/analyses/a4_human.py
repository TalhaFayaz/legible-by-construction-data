"""Review Major 3 (existing ratings): do the geometric measures still track the
raters when the broken model-placement images are left out, and how well do the
raters agree with each other?

- rho per metric over all 72 images (as in the paper) and over the 48 images
  drawn by our engine or by dot only;
- each rater's BWS scores (from their own judgements) and the pairwise Spearman
  correlation between raters, all 72 and ours+dot only;
- Kendall's W over raters, from each rater's per-image BWS ranks.
Rater names are replaced by R1..R3 in sorted file order."""
import itertools
import json
import sys
from pathlib import Path

import numpy as np
from scipy.stats import rankdata

sys.path.insert(0, "<home>")
from ab.pdf.eval.HumanStudy import METRICS, Judgement, bws_scores, spearman  # noqa: E402
from ab.pdf.metric.Geometry import LayoutReport  # noqa: E402

H = Path("<home>")
stim = json.loads((H / "stimuli.json").read_text())
tuples = stim["tuples"]
cond = {sid: s["condition"] for sid, s in stim["stimuli"].items()}
reports = {sid: LayoutReport.model_validate(s["report"]) for sid, s in stim["stimuli"].items()}

judgements = []
files = sorted((H / "ratings").glob("ratings_*.json"))
for i, f in enumerate(files, 1):
    data = json.loads(f.read_text())
    rows = data["judgements"] if isinstance(data, dict) and "judgements" in data else data
    for d in rows:
        d = dict(d); d["rater"] = f"R{i}"
        judgements.append(Judgement.model_validate(d))

human = bws_scores(judgements, tuples)
out = [f"raters {len(files)}, judgements {len(judgements)}, images {len(human)}"]
for subset, ids in (("all 72 images", sorted(human)),
                    ("ours + dot only (48)", sorted(k for k in human if cond[k] in ("ours", "graphviz")))):
    out.append(f"\nSpearman rho with the raters' BWS score, {subset} (sign: agreement)")
    for name, get in METRICS.items():
        xs = [get(reports[k]) for k in ids]
        if len(set(xs)) < 2:
            out.append(f"  {name:<24} no variance"); continue
        out.append(f"  {name:<24} {spearman(xs, [human[k] for k in ids]):+.3f}")

per = {r: bws_scores([j for j in judgements if j.rater == r], tuples) for r in sorted({j.rater for j in judgements})}
for subset, keep in (("all 72", lambda k: True), ("ours + dot", lambda k: cond[k] in ("ours", "graphviz"))):
    ids = sorted(k for k in human if keep(k) and all(k in p for p in per.values()))
    out.append(f"\nbetween raters, {subset} ({len(ids)} images): pairwise Spearman of BWS scores")
    for a, b in itertools.combinations(per, 2):
        out.append(f"  {a} vs {b}: {spearman([per[a][k] for k in ids], [per[b][k] for k in ids]):+.3f}")
    ranks = np.array([rankdata([per[r][k] for k in ids]) for r in per])
    m, n = ranks.shape
    s = ((ranks.sum(0) - ranks.sum(0).mean()) ** 2).sum()
    out.append(f"  Kendall's W ({m} raters): {12 * s / (m ** 2 * (n ** 3 - n)):.3f}")

for r, p in per.items():
    means = {c: np.mean([v for k, v in p.items() if cond[k] == c]) for c in ("ours", "graphviz", "model")}
    out.append(f"\n{r} mean BWS: " + ", ".join(f"{c} {v:+.3f}" for c, v in means.items()))
print("\n".join(out))
