"""Control-flow mode (development; not in the repo until it is chosen).

When the input text is a program, the extractor is asked for the program's
control flow (statements in execution order, conditions as decisions, loops as
edges back to their condition) instead of the component graph the general
prompt asks for. Same schema, same constrained decoding, same layout engine.
"""
import re

# a line that only a program contains
_CODE_LINE = re.compile(
    r"""^\s*(
        (def|class)\s+\w+\s*[\(:]          |   # python definitions
        (for|while)\b.*:\s*$                |   # python loops
        (if|elif|else|try|except|with)\b.*:\s*$ |
        return\b                            |
        import\s+\w+ | from\s+\w+\s+import\b |
        [A-Za-z_][\w\.\[\]]*\s*(\+|-|\*|/)?=\s*[^=]  |   # assignment
        [A-Za-z_][\w\.]*\(.*\)\s*;?\s*$     |   # a bare call
        [{}]\s*$ | .*;\s*$                      # C-like
    )""", re.X)


def is_code(text: str, share: float = 0.5, minimum: int = 3) -> bool:
    """True when most non-empty, non-comment lines are program statements.

    Fixed before any evaluation: at least ``minimum`` code lines, and at least
    ``share`` of the non-empty lines that are not comments.
    """
    lines = [l for l in text.splitlines() if l.strip() and not l.strip().startswith(("#", "//"))]
    if not lines:
        return False
    code = sum(bool(_CODE_LINE.match(l)) for l in lines)
    return code >= minimum and code / len(lines) >= share


CODE_SYSTEM = """You are an expert programmer who draws precise flowcharts of
programs. You draw only what the program does."""

CODE_PROMPT = """The passage below is a program. Draw its flowchart: the
CONTROL FLOW of the program, the way a programmer's flowchart shows it.

- Nodes are the program's STEPS in execution order, not its variables or
  objects. Never make a node for a variable, an argument or an object by itself.
- Begin with a node labelled "Start" and finish with a node labelled "End".
- The function's parameters are one node of type "input" ("Input: ...").
- Each assignment, call, update, print or return is a node of type "process"
  ("output" for a return or a print). Describe it in a short plain-English
  phrase that keeps the program's own names, e.g. "Initialize 'mpis' with
  zeros", "Return the maximum of 'mpis'".
- Each if, elif, while and for is a node of type "decision" phrased as a check:
  "Check if 'i' < 'n'", "Check if 'arr[i]' > 'arr[j]'". Its outgoing edges
  carry condition "Yes" or "No".
- A loop: the decision's "Yes" edge goes into the body; the last step of the
  body has an edge of kind "feedback" back to the decision; the "No" edge goes
  to the first step after the loop.
- Connect every step to the step that runs next. Edge "label" stays empty;
  only edges leaving a decision get a "condition".
- Do not use "children" or groups, and do not use "attributes".
- Every node's "type" is exactly one of: process, decision, input, output.
- Every edge's "kind" is exactly one of: flow, feedback.
- Every edge endpoint must be an id declared in "nodes".

Program:
{text}
"""

CODE_COVERAGE_PROMPT = """A first pass drew this flowchart of the program below.

Already drawn:
NODES: {nodes}
EDGES: {edges}

Find what is MISSING from the control flow: statements, conditions or loop
checks of the program that have no node, and transitions between existing
steps that have no edge (especially a loop's edge back to its check, and the
"No" edge that leaves a loop or an if). Never add nodes for variables or
objects. Edges leaving a decision carry condition "Yes" or "No".

Return a flowchart in the same schema containing ONLY the additions. Return
empty lists if nothing is missing. Do not repeat what is already there.

Program:
{text}
"""
