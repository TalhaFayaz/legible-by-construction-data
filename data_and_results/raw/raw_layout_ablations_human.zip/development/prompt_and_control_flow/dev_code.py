"""Development check of the control-flow mode (never reported as a result).

DEV SET (fixed before running): 60 FlowVQA *train* code items, seed 3, drawn
with random.Random(3).sample from the train code keys whose program the code
detector recognises and whose program text does not occur in the test split.

VARIANTS: v3  = current pipeline (prompt revision 3 + coverage pass)
          cf  = control-flow prompt, no coverage pass
          cfc = control-flow prompt + control-flow coverage pass
All with n = 2 candidates and the pipeline's geometric selection; model Qwen
(qwen25-vl-32b), VLLM_SEED 0, as in the earlier prompt development.

DECISION RULE (fixed before running):
  1. Metric: the official score (0.4 node F1 + 0.6 edge F1) per item.
  2. A control-flow variant qualifies only if its mean score is above v3's and
     a paired two-sided Wilcoxon test against v3 gives p < 0.05, and it fails
     on no more items than v3.
  3. Of the qualifying variants, take the one with the higher mean; if the two
     means differ by less than 0.01, take cf (simpler: no coverage pass).
  4. If none qualifies, the control-flow mode is dropped and nothing changes.

    PYTHONPATH=. python3 dev_code.py VARIANT OUT.jsonl
"""
import json
import logging
import random
import sys
import time
from pathlib import Path

logging.disable(logging.CRITICAL)
sys.path.insert(0, str(Path(__file__).parent))

from ab.pdf.corpus import FlowVQA
from ab.pdf.eval.RunCorpus import _gold_native
from ab.pdf.metric.SciFlowNative import evaluate, figure_to_native

import control_flow as cf_mod

variant, out = sys.argv[1], Path(sys.argv[2])


def dev_keys():
    train = json.loads(Path("data/flowvqa/train_full.json").read_text())
    test_codes = {v.get("code") for v in json.loads(Path("data/flowvqa/test_full.json").read_text()).values()}
    keys = sorted(k for k, r in train.items() if k.startswith("code")
                  and r["code"] not in test_codes and cf_mod.is_code(FlowVQA.prompt_of(r)))
    return train, sorted(random.Random(3).sample(keys, 60))


def item_of(key, rec):
    return FlowVQA.BenchItem(paper_id=key, domain=key[:4], prompt=FlowVQA.prompt_of(rec),
                             gold_graph=FlowVQA.parse_mermaid(rec["mermaid"]),
                             gold_layout=FlowVQA.Layout(), baselines={})


def ours(item):
    import ab.pdf.agent.Extractor as X
    from ab.pdf.agent.Prepare import prepare
    from ab.pdf.eval.VlmAdapter import figure_to_planner_json, prepared_to_layout
    from ab.pdf.metric.Geometry import evaluate_layout

    if variant in ("cf", "cfc"):
        X.EXTRACTOR_PROMPT = cf_mod.CODE_PROMPT
        X.EXTRACTOR_SYSTEM = cf_mod.CODE_SYSTEM
        X.COVERAGE_PROMPT = cf_mod.CODE_COVERAGE_PROMPT
    figures = X.extract(item.prompt, n=2, coverage=(variant != "cf"))
    if not figures:
        raise RuntimeError("no valid candidate")
    best = None
    for fig in figures:
        report = evaluate_layout(prepared_to_layout(prepare(figure_to_planner_json(fig), 1.0)))
        key = (report.valid, -report.edge_node_crossings, -report.edge_edge_crossings)
        if best is None or key > best[0]:
            best = (key, fig)
    return figure_to_native(best[1])


if __name__ == "__main__":
    train, keys = dev_keys()
    done = {json.loads(l)["paper_id"] for l in out.read_text().splitlines()} if out.exists() else set()
    with out.open("a") as handle:
        for key in keys:
            if key in done:
                continue
            item = item_of(key, train[key])
            started = time.time()
            try:
                nodes, edges = ours(item)
                failed = False
            except Exception as e:
                nodes, edges, failed = [], [], str(e)[:120]
            g_nodes, g_edges = _gold_native(item)
            native = evaluate(g_nodes, g_edges, nodes, edges).model_dump()
            handle.write(json.dumps({"variant": variant, "paper_id": key, "failed": failed,
                                     "nodes": len(nodes), "edges": len(edges), "native": native,
                                     "seconds": round(time.time() - started, 1)}) + "\n")
            handle.flush()
