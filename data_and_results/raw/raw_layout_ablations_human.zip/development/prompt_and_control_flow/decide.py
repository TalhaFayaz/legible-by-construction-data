"""Apply the decision rule written in dev_code.py to the finished dev runs.
Prints the verdict and writes decision.txt ("cf", "cfc" or "none")."""
import json
from pathlib import Path

from scipy.stats import wilcoxon

D = Path(__file__).parent
R = {v: {json.loads(l)["paper_id"]: json.loads(l) for l in (D / f"dev_code_{v}.jsonl").read_text().splitlines()}
     for v in ("v3", "cf", "cfc")}
ids = sorted(set.intersection(*(set(r) for r in R.values())))
assert len(ids) == 60, f"dev runs incomplete: {len(ids)} common items"
score = lambda v: [R[v][i]["native"]["final_score"] for i in ids]
fails = lambda v: sum(bool(R[v][i]["failed"]) for i in ids)
mean = lambda v: sum(score(v)) / len(ids)

lines = [f"{v}: mean score {mean(v):.3f}, failed {fails(v)}" for v in R]
qualify = []
for v in ("cf", "cfc"):
    p = wilcoxon([a - b for a, b in zip(score(v), score("v3"))]).pvalue
    ok = mean(v) > mean("v3") and p < 0.05 and fails(v) <= fails("v3")
    lines.append(f"{v} vs v3: diff {mean(v) - mean('v3'):+.3f}, Wilcoxon p {p:.2g} -> {'qualifies' if ok else 'does not qualify'}")
    if ok:
        qualify.append(v)
if not qualify:
    choice = "none"
elif len(qualify) == 1:
    choice = qualify[0]
else:
    choice = "cf" if abs(mean("cf") - mean("cfc")) < 0.01 else max(qualify, key=mean)
lines.append(f"DECISION: {choice}")
print("\n".join(lines))
(D / "decision.txt").write_text(choice + "\n" + "\n".join(lines) + "\n")
