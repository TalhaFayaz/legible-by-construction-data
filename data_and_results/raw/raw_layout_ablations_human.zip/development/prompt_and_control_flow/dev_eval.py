"""Development check of extraction prompts (never reported as results).

Dev set: 60 FlowVQA *train* items (20 per source, seed 1, the one text shared
with the test split removed) + 40 seeded SciFlow papers (named in the paper).

    PYTHONPATH=. python3 dev_eval.py VARIANT OUT.jsonl     VARIANT = v1 | v2 | dot
"""
import json
import logging
import random
import sys
import time
from pathlib import Path

logging.disable(logging.CRITICAL)
sys.path.insert(0, str(Path(__file__).parent))

from ab.pdf.corpus import FlowVQA
from ab.pdf.corpus.AutoBench import load_item
from ab.pdf.eval.RunCorpus import _gold_native
from ab.pdf.metric.SciFlowNative import evaluate, figure_to_native

variant, out = sys.argv[1], Path(sys.argv[2])
R = Path("runs")


def dev_items():
    train = json.loads(Path("data/flowvqa/train_full.json").read_text())
    test_texts = {v.get("text") or v.get("code")
                  for v in json.loads(Path("data/flowvqa/test_full.json").read_text()).values()}
    for key in FlowVQA.sample_keys(train, per_source=21, seed=1):
        rec = train[key]
        if (rec.get("text") or rec.get("code")) in test_texts:
            continue
        yield "flowvqa", FlowVQA.BenchItem(paper_id=key, domain=key[:4], prompt=FlowVQA.prompt_of(rec),
                                           gold_graph=FlowVQA.parse_mermaid(rec["mermaid"]),
                                           gold_layout=FlowVQA.Layout(), baselines={})
    gold = json.loads((R / "inverse/gold.json").read_text())
    keys = sorted(gold)
    random.Random(7).shuffle(keys)
    for key in sorted(keys[:40]):
        domain, paper = key.split("/")
        yield "sciflow", load_item(Path("data/sciflow_raw") / domain / paper, domain=domain)


def ours(item):
    from ab.pdf.agent.Extractor import extract
    from ab.pdf.agent.Prepare import prepare
    from ab.pdf.eval.VlmAdapter import figure_to_planner_json, prepared_to_layout
    from ab.pdf.metric.Geometry import evaluate_layout

    figures = extract(item.prompt, n=2, coverage=True)
    best = None
    for fig in figures:
        report = evaluate_layout(prepared_to_layout(prepare(figure_to_planner_json(fig), 1.0)))
        key = (report.valid, -report.edge_node_crossings, -report.edge_edge_crossings)
        if best is None or key > best[0]:
            best = (key, fig)
    return figure_to_native(best[1])


def dot(item):
    import os
    from ab.pdf.agent.Model import ask
    from ab.pdf.eval.DotBaseline import PROMPT, SYSTEM, dot_graph, extract_dot

    source = extract_dot(ask(PROMPT.format(text=item.prompt), system=SYSTEM))
    return dot_graph(source, os.environ["DOT"])


if variant in ("v2", "v3"):
    import importlib
    import ab.pdf.agent.Extractor as extractor
    revision = importlib.import_module(f"prompt_{variant}")
    extractor.EXTRACTOR_PROMPT = revision.EXTRACTOR_PROMPT
    extractor.COVERAGE_PROMPT = revision.COVERAGE_PROMPT

done = {json.loads(l)["paper_id"] for l in out.read_text().splitlines()} if out.exists() else set()
with out.open("a") as handle:
    for corpus, item in dev_items():
        if item.paper_id in done:
            continue
        started = time.time()
        try:
            nodes, edges = dot(item) if variant == "dot" else ours(item)
            failed = False
        except Exception as e:
            nodes, edges, failed = [], [], str(e)[:120]
        g_nodes, g_edges = _gold_native(item)
        native = evaluate(g_nodes, g_edges, nodes, edges).model_dump()
        handle.write(json.dumps({"corpus": corpus, "source": item.domain, "paper_id": item.paper_id,
                                 "failed": failed, "nodes": len(nodes), "edges": len(edges),
                                 "native": native, "seconds": round(time.time() - started, 1)}) + "\n")
        handle.flush()
