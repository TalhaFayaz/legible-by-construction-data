"""Revision 2 of the extraction prompts: the original word for word, widened in
three places. The original listed only components a system is built from and
connected only verbs that move something between them, so a procedure's steps
-- and the order they come in -- were never extracted."""
from ab.pdf.agent import Extractor

_P = Extractor.EXTRACTOR_PROMPT
_C = Extractor.COVERAGE_PROMPT


def _swap(text, old, new):
    assert old in text, old[:60]
    return text.replace(old, new)


EXTRACTOR_PROMPT = _swap(_P, """STEP 1 -- list every noun phrase in the passage that names a system, component,
service, tool, store, gate or check. Every one becomes a node.""",
"""STEP 1 -- list every noun phrase in the passage that names a system, component,
service, tool, store, data object, gate or check, and every step or action the
passage describes a process going through -- a stage of a method, a step of a
procedure, an operation of an algorithm. Every one becomes a node.""")

EXTRACTOR_PROMPT = _swap(EXTRACTOR_PROMPT, """STEP 3 -- connect the rest. Read the passage again looking only for verbs that
move something between two named components.""",
"""STEP 3 -- connect the rest. Read the passage again looking for verbs that move
something between two named components, and for steps the passage puts in
order: when it says one step follows another ("then", "next", "after that", or
simply the order in which it lists them), connect each step to the step that
follows it.""")

COVERAGE_PROMPT = _swap(_C, """1. Components the passage names that are absent from the node list above.""",
"""1. Components, data objects and steps the passage names that are absent from
   the node list above.""")
