"""Revision 3: revision 2 plus one rule for programs and pseudocode, whose steps
are statements: the first revisions left the model to summarise code into a
few coarse steps, while a reader of a program's flowchart expects its
statements, conditions and loops."""
import prompt_v2

EXTRACTOR_PROMPT = prompt_v2._swap(prompt_v2.EXTRACTOR_PROMPT,
"""procedure, an operation of an algorithm. Every one becomes a node.""",
"""procedure, an operation of an algorithm. Every one becomes a node. When the
passage is a program or pseudocode, its steps are its statements: each
assignment, call, input, output and return is a step, each condition (if,
while, for) is a decision node, and a loop is an edge from the end of its body
back to its condition.""")
COVERAGE_PROMPT = prompt_v2.COVERAGE_PROMPT
